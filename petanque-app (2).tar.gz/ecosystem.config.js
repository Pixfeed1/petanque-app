module.exports = {
  apps: [{
    name: 'petanque',
    script: 'server.js',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      DATABASE_URL: 
'postgresql://jurojinn_petanque_user:Vashthestampede2a.@localhost:5432/jurojinn_petanque_app',
      JWT_SECRET: '34d80b9b2afb4476441c1728e8e625a2e1b379025abb61d5ae6812671935dc06',
      NEXT_PUBLIC_APP_URL: 'https://petanquepro.fr'
    }
  }]
}
